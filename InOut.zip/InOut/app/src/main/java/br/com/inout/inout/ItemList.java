package br.com.inout.inout;

public class ItemList {
    private String titulo, categoria, desconto, avaliacao, imagem;

    public ItemList(String titulo, String categoria, String desconto, String avaliacao, String imagem) {
        this.titulo = titulo;
        this.categoria = categoria;
        this.desconto = desconto;
        this.avaliacao = avaliacao;
        this.imagem = imagem;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getDesconto() {
        return desconto;
    }

    public void setDesconto(String desconto) {
        this.desconto = desconto;
    }

    public String getAvaliacao() {
        return avaliacao;
    }

    public void setAvaliacao(String avaliacao) {
        this.avaliacao = avaliacao;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }
}
