package br.com.inout.inout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class ListActivity extends BaseActivity {

    private ArrayList<ItemList> itens;
    private ListView listView;
    private AdapterListView adapterListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        listView = (ListView) findViewById(R.id.lista);
        itens = new ArrayList<>();

        itens.add(new ItemList("Título 1", "Categoria 1", "10%", "4.1", ""));
        itens.add(new ItemList("Título 2", "Categoria 2", "20%", "4.3", ""));
        itens.add(new ItemList("Título 3", "Categoria 3", "30%", "4.2", ""));
        itens.add(new ItemList("Título 4", "Categoria 4", "40%", "4.4", ""));
        itens.add(new ItemList("Título 5", "Categoria 5", "50%", "4.5", ""));
        itens.add(new ItemList("Título 6", "Categoria 6", "60%", "4.6", ""));

        adapterListView = new AdapterListView(ListActivity.this, itens);
        listView.setAdapter(adapterListView);


    }
}
