package br.com.inout.inout;


import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class ListFragment extends Fragment {

    private ArrayList<ItemList> itens;
    private ListView listView;
    private AdapterListView adapterListView;
    private View mView;

    public ListFragment() {
        // Required empty public constructor
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        mView = inflater.inflate(R.layout.fragment_list, container, false);

        listView = (ListView) mView.findViewById(R.id.lista);
        itens = new ArrayList<ItemList>();
        itens.add(new ItemList("Título 1", "Categoria 1", "10%", "4.1", ""));
        itens.add(new ItemList("Título 2", "Categoria 2", "20%", "4.3", ""));
        itens.add(new ItemList("Título 3", "Categoria 3", "30%", "4.2", ""));
        itens.add(new ItemList("Título 4", "Categoria 4", "40%", "4.4", ""));
        itens.add(new ItemList("Título 5", "Categoria 5", "50%", "4.5", ""));
        itens.add(new ItemList("Título 6", "Categoria 6", "60%", "4.6", ""));

        adapterListView = new AdapterListView(getContext(), itens);
        listView.setAdapter(adapterListView);
        // Inflate the layout for this fragment
        return mView;
    }

}
